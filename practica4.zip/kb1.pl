girl(priya).
girl(natasha).
girl(jasmin).

can_cook(priya).
