hates(jim, tom).
hates(pat, bob).
hates(dog, fox).
hates(peter, tom).
