gt(X,Y) :- X >= Y, write('X is greater or equal').
gt(X,Y) :- X <  Y, write('X is smaller').

gte(X,Y) :- X >   Y, write('X is greater').
gte(X,Y) :- X =:= Y, write('X and Y are same').
gte(X,Y) :- X <   Y, write('X is smaller').
